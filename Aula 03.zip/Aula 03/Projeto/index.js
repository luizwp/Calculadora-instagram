function calculateEngagement() {
    var engaged = document.getElementById("engaged").value;
    var reached = document.getElementById("reached").value;

    if (reached > 0) {
        var engagementRate = (engaged / reached) * 100;
        var statusMessage = getStatusMessage(engagementRate);
        document.getElementById("engagementResult").innerHTML = `Taxa de Engajamento: ${engagementRate.toFixed(2)}% - ${statusMessage}`;
        document.getElementById("engagementTips").innerHTML = getEngagementTips(engagementRate);
    }
}
function validateInput(value) {
    return value > 0 && !isNaN(value);
}
function getStatusMessage(rate) {
    if (rate < 5) {
        return "Ruim";
    } else if (rate >= 5 && rate <= 10) {
        return "Bom";
    } else {
        return "Ótimo";
    }
}